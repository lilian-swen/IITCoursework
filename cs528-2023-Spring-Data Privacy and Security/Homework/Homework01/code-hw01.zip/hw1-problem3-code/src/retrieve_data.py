import os

# Ref: adult.names
FILE_PATH = '../data'
FILE_NAME = 'adult.data'
ADULT_NAMES = ['age', 'workclass', 'fnlwgt', 'education', 'education_num',
               'marital-status', 'occupation', 'relationship', 'race', 'sex',
               'capital-gain', 'capital-loss', 'hours-per-week', 'native-country', 'salary']

# Defined hierarchies
AGE_DATA = '../hierarchy/age_hierarchy.txt'
EDUCATION_DATA = '../hierarchy/education_hierarchy.txt'
MARRIAGE_DATA = '../hierarchy/marital-status_hierarchy.txt'
RACE_DATA = '../hierarchy/race_hierarchy.txt'


def readdata(filepath=FILE_PATH, filename=FILE_NAME):
    records = []
    try:
        with open(os.path.join(filepath, filename), 'r') as read_file:
            for line in read_file:
                line = line.strip()
                if not line:
                    continue
                line = [a.strip() for a in line.split(',')]
                # print(line)
                intidx = [ADULT_NAMES.index(colname) for colname in (
                    'age', 'fnlwgt', 'education_num', 'capital-gain', 'capital-loss', 'hours-per-week')]
                for idx in intidx:
                    try:
                        line[idx] = int(line[idx])
                    except:
                        print('attribute %s, value %s, cannot be converted to number' % (ADULT_NAMES[idx], line[idx]))
                        line[idx] = -1
                for idx in range(len(line)):
                    if line[idx] == '' or line[idx] == '?':
                        line[idx] = '*'
                records.append(line)
        return records
    except:
        print('cannot open file: %s:%s' % (filepath, filename))


def _copy_with_exclude_idx(datasets, target_idx):
    return [record for idx, record in enumerate(datasets) if idx != target_idx]


def generate_hierarchy_for_age(datasets):
    age_idx = ADULT_NAMES.index('age')
    ages = [record[age_idx] for record in datasets if record[age_idx] != -1]
    min_age, max_age = min(ages), max(ages)
    print(f"age max: {max_age} min: {min_age}")

    with open(AGE_DATA, 'w') as wf:
        for i in range(max_age + 1):
            wf.write(f"{i},{i//25 * 25}-{(i//25 + 1) * 25},{i//50 * 50}-{(i//50 + 1) * 50},{i//100 * 100}-{(i//100 + 1) * 100}\n")


def generate_hierarchy_for_edu(datasets):
    eduset = set()
    eduidx = ADULT_NAMES.index('education')
    for record in datasets:
        if record[eduidx] != '*':
            eduset.add(record[eduidx])
    edu_data = "\n".join([edu + ',' * 2 for edu in eduset])
    with open(EDUCATION_DATA, 'w') as wf:
        wf.write(edu_data)


def generate_hierarchy_for_marital(datasets):
    marital_idx = ADULT_NAMES.index('marital-status')
    marital_statuses = set(record[marital_idx] for record in datasets if record[marital_idx] != '*')
    with open(MARRIAGE_DATA, 'w') as wf:
        wf.write('\n'.join([status + ',' * 2 for status in marital_statuses]))


def generate_hierarchy_for_race(datasets):
    races = set(record[ADULT_NAMES.index('race')] for record in datasets if record[ADULT_NAMES.index('race')] != '*')
    with open(RACE_DATA, 'w') as f:
        for race in races:
            f.write(f"{race},,\n")


if __name__ == "__main__":
    print("Files directory: " + os.getcwd())
    records = readdata()
    # generate_hierarchy_for_age(records)
#     generate_hierarchy_for_edu(records)
#     generate_hierarchy_for_marital(records)
    generate_hierarchy_for_race(records)
