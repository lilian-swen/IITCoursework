from src.retrieve_data import *
from DGHTree import *


class KAnonymity():
    def __init__(self, datasets):
        self.datasets = datasets
        self.defined_hierarchy = [AGE_DATA, EDUCATION_DATA, MARRIAGE_DATA, RACE_DATA]

    def calc_precision(self, generalized_levels, max_depth, data_size, attribute_num=4):
        precision = 1 - sum([generalized_levels[i] / max_depth[i] for i in range(attribute_num)]) / (
                data_size * attribute_num)
        return precision

    def calc_distoration(self, generalized_levels, max_depth, attribute_num):
        print('Generalized level of attribute:', generalized_levels)
        print('Depth of the hierarchy:', max_depth)
        distoration = sum([generalized_levels[i] / max_depth[i] for i in range(attribute_num)]) / attribute_num
        return distoration

    def anonymize_func(self, quasi=['age', 'education', 'marital-status', 'race'], k=5):
        """
        k-anonymity: Given k = 5
        Arguments: {['age', 'education', 'marital-status', 'race']}
        """

        identifiers, generalized_levels = dict(), dict()
        qi_frequency = dict()

        if not len(self.defined_hierarchy) == len(quasi):
            raise ValueError('number of files is not equal to number of quasi!!!!')

        hierarchy = dict()
        for idx, name in enumerate(quasi):
            hierarchy[name] = DGHTree(self.defined_hierarchy[idx])

        for identifier in quasi:
            identifiers[identifier] = set()
            generalized_levels[identifier] = 0

        for idx, record in enumerate(self.datasets):
            qi_sequence = self._get_qi_values(record[:], quasi, hierarchy)

            if qi_sequence in qi_frequency:
                qi_frequency[qi_sequence].add(idx)
            else:
                qi_frequency[qi_sequence] = {idx}
                for j, value in enumerate(qi_sequence):
                    identifiers[quasi[j]].add(value)

        # With maximum distinct values, iteratively generalize the attributes
        while True:
            # number of records which is not satisfied k-anonymity
            invalid_count = 0
            for qi_sequence, idxset in qi_frequency.items():
                if len(idxset) < k:
                    invalid_count += len(idxset)

            if invalid_count > k:
                # keep generalizing
                most_freq_att_num, most_freq_att_name = -1, None
                for identifier in quasi:
                    if len(identifiers[identifier]) > most_freq_att_num:
                        most_freq_att_num = len(identifiers[identifier])
                        most_freq_att_name = identifier

                generalize_att = most_freq_att_name
                qi_index = quasi.index(generalize_att)
                identifiers[generalize_att] = set()

                for qi_sequence in list(qi_frequency.keys()):
                    new_qi_sequence = list(qi_sequence)
                    new_qi_sequence[qi_index] = hierarchy[generalize_att].root[qi_sequence[qi_index]][0]
                    new_qi_sequence = tuple(new_qi_sequence)

                    if new_qi_sequence in qi_frequency:
                        qi_frequency[new_qi_sequence].update(
                            qi_frequency[qi_sequence])
                        qi_frequency.pop(qi_sequence, 0)
                    else:
                        qi_frequency[new_qi_sequence] = qi_frequency.pop(qi_sequence)

                    identifiers[generalize_att].add(new_qi_sequence[qi_index])

                generalized_levels[generalize_att] += 1


            else:
                # suppress sequences which is not satisfied k-anonymity & store results and calculate distoration and precision
                genlvl_att = [0 for _ in range(len(quasi))]
                dgh_att = [hierarchy[name].level for name in quasi]
                datasize = 0
                qiindex = [ADULT_NAMES.index(name) for name in quasi]

                # used to make sure the output file keeps the same order with original data file
                towriterecords = [None for _ in range(len(self.datasets))]
                with open('../output/adult_%d_kanonymity.data' % k, 'w') as wf:
                    for qi_sequence, recordidxs in qi_frequency.items():
                        if len(recordidxs) < k:
                            continue
                        for idx in recordidxs:
                            record = self.datasets[idx][:]
                            for i in range(len(qiindex)):
                                record[qiindex[i]] = qi_sequence[i]
                                genlvl_att[i] += hierarchy[quasi[i]].root[qi_sequence[i]][1]
                            record = list(map(str, record))
                            for i in range(len(record)):
                                if record[i] == '*' and i not in qiindex:
                                    record[i] = '?'
                            towriterecords[idx] = record[:]
                        datasize += len(recordidxs)
                    for record in towriterecords:
                        if record is not None:
                            wf.write(', '.join(record))
                            wf.write('\n')
                        else:
                            wf.write('\n')

                print('quasi identifiers: ', quasi)
                precision = self.calc_precision(genlvl_att, dgh_att, len(self.datasets), len(quasi))
                distoration = self.calc_distoration([generalized_levels[quasi[i]] for i in range(len(quasi))], dgh_att,
                                                    len(quasi))
                print('precision: {}, distoration: {}'.format(precision, distoration))
                break

    def _get_qi_values(self, record, identifiers, DGHtree):
        """
         Returns: tuple
        """
        qi_index = [ADULT_NAMES.index(name) for name in identifiers]
        seq = []
        for idx in qi_index:
            if idx == ADULT_NAMES.index('age'):
                if record[idx] == -1:
                    seq.append('0-100')
                else:
                    seq.append(str(record[idx]))
            else:
                if record[idx] == '*':
                    record[idx] = DGHtree[identifiers[idx]].highestgen
                seq.append(record[idx])
        return tuple(seq)


if __name__ == "__main__":
    datasets = readdata()
    k_anonymity = KAnonymity(datasets)
    # Test 01
    # k_anonymity.anonymize_func(k=100)

    # Test 02
    # k_anonymity.anonymize_func(k=10)

    # Test 03
    k_anonymity.anonymize_func(k=50)
