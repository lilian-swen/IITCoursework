class DGHTree:
    """
     Track each node's parent and current level
    """

    def __init__(self, hierarchy_file):
        self.hierarchy_file = hierarchy_file
        self.root = {}
        self.level = -1
        self.highestgen = ''
        self._build_tree()

    def _build_tree(self):
        with open(self.hierarchy_file, 'r') as hierarchy:
            for line in hierarchy:
                line = line.strip()
                if not line:
                    continue
                elements = [col.strip() for col in line.split(',')]
                depth = len(elements) - 1
                if self.level == -1:
                    self.level = depth
                if not self.highestgen:
                    self.highestgen = elements[-1]
                parent = None
                for index, value in enumerate(elements[::-1]):
                    self.root[value] = (parent, depth - index)
                    parent = value
