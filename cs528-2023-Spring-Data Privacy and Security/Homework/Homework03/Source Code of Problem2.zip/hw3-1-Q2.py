import math

p = 9497
q = 7187
e = 3

'''
Q2 - 1st"
'''


def cal_n_phi_N():
    N = p * q
    phi_N = (p - 1) * (q - 1)
    print("Q2 - 1st: ", "N =", N, "Φ(N) =", phi_N)


'''
Q2 - 2nd: check if the greatest common divisor (GCD) of e and Φ(N) is 1.
'''


def gcd(a, b):
    if isinstance(a, tuple):
        a = a[0]
    if isinstance(b, tuple):
        b = b[0]
    while b != 0:
        a, b = b, a % b
    return a


def gcd_ver2():
    p = 9497
    q = 7187
    e = 3

    N = p * q
    phi_N = (p - 1) * (q - 1)

    gcd = math.gcd(e, phi_N)

    if gcd == 1:
        print("e is relatively prime to Φ(N)")
    else:
        print("e is not relatively prime to Φ(N)")


'''
Q2 - 3rd
This function takes two integers a and b as input and returns a tuple (gcd, x, y)
where gcd is the greatest common divisor of a and b,
x and y are the coefficients that satisfy the equation: a * x + b * y = gcd

To compute d as the inverse of e modulo Φ(N), we can use the extended Euclidean algorithm. 
'''


def extended_euclidean_algorithm(a, b):
    if b == 0:
        return a, 1, 0
    else:
        gcd, x, y = extended_euclidean_algorithm(b, a % b)
        return gcd, y, x - (a // b) * y


def extended_euclidean_algorithm_ver2():
    p = 9497
    q = 7187
    e = 3

    N = p * q
    phi_N = (p - 1) * (q - 1)

    if gcd != 1:
        raise ValueError("e is not invertible modulo Φ(N)")

    d = pow(e, -1, phi_N)
    print("Q2 - 3rd: d =  the inverse of e mod Φ(N) =", d)


'''
an example of how to use this function to find the inverse of e modulo Φ(N);
What's coprime?
Two integers are said to be coprime (or relatively prime) if their greatest common divisor (GCD) 
is 1. In other words, two integers are coprime if they have no common divisors other than 1.

For example, 5 and 7 are coprime because their only common divisor is 1. However, 6 and 10 are 
not coprime because they have a common divisor of 2.
'''


def find_inverse(e, phi_n):
    '''Q2 - 3rd'''
    gcd, x, y = extended_euclidean_algorithm(e, phi_n)
    if gcd != 1:
        raise ValueError('e and Φ(N) are not coprime')
    else:
        return x % phi_n


'''
Q2 - 4th
Encrypt the value P = 22446688 with the RSA primitive and the values for N and e above. 
Let C be the resulting ciphertext. What is C?

To encrypt the plaintext P = 22446688 using RSA, we need to compute its ciphertext C using the public key (N, e). 
'''


def encrypt():
    p = 9497
    q = 7187
    e = 3
    N = p * q
    phi_N = (p - 1) * (q - 1)

    # Set the plaintext value
    P = 22446688

    # Calculate the ciphertext value
    # Equivalent to base**exp with 2 arguments or base**exp % mod with 3 arguments
    # C = P^e mod N
    C = pow(P, e, N)

    # Print the ciphertext
    print("Q2 - 4th: Let C be the resulting ciphertext. The ciphertext is:", C)


def encrypt_4th():
    p = 9497
    q = 7187
    e = 3
    P = 22446688

    N = p * q
    phi_N = (p - 1) * (q - 1)

    gcd = math.gcd(e, phi_N)

    if gcd != 1:
        raise ValueError("e is not invertible modulo Φ(N)")

    C = pow(P, e, N)

    print("Q2 - 4th: C =", C)


'''
Q2 - 5th
Verify that you can decrypt C using d as the private exponent to get back P. 
To decrypt C using d as the private exponent to get back P, we need to use the formula P = C^d mod N
It means that we raise C to the power of d and then take the remainder when dividing by N
where d is the private exponent.
----------------------------------------------------------------------------------------------
To find d, we need to compute the modular multiplicative inverse of e modulo phi(N). 
We can use the extended Euclidean algorithm for this: e * d + phi(N) * k = 1
where k is an integer. We want to solve for d, so we need to rearrange this equation: e * d = 1 - phi(N) * k
'''


def decryption_c():
    C = 23081176
    p = 22446688
    d = 45492171
    N = 68254939
    decrypted_p = pow(C, d, N)
    if decrypted_p == p:
        print("Q2 - 5th: Decryption successful. Decrypted P is equal to original P.")
    else:
        print("Q2 - 5th: Decryption failed. Decrypted P is not equal to original P.")


'''
Q2 - 6th
To decrypt the value C' using the RSA primitive, we can use the formula: P' = C'^d mod N

We have already computed the value of d in the previous step, and we know the value of N. 
So, we can simply substitute the values of C' and d in the formula and compute P'. 
'''


def decryption_c_p():
    p = 9497
    q = 7187
    d = 45492171
    C_prime = 11335577
    N = p * q
    P_prime = pow(C_prime, d, N)
    print("Q2 - 6th: The decrypted plaintext is:", P_prime)


'''
Q2 - 7th

To verify that we can encrypt P' using e as the public exponent to get back C', we can simply compute:
C'' = P'^e mod N

If C'' is equal to C', then we have successfully verified that we can encrypt P' using e as 
the public exponent to get back C'.
'''


def encript_p_prime():
    p = 9497
    q = 7187
    d = 45492171
    C_prime = 11335577
    N = p * q
    P_prime = pow(C_prime, d, N)

    encrypted_C2 = pow(P_prime, e, N)
    # print("Encrypted C' =", encrypted_C2)
    # print("Original C' =", C_prime)

    if encrypted_C2 == C_prime:
        print("Q2 - 7th: Encryption successful. Encrypted C' is equal to original C'.")
    else:
        print("Q2 - 7th: Encryption failed. Encrypted C' is not equal to original C'.")


# def encript_p_prime_7th():
#     p = 9497
#     q = 7187
#     e = 3
#     P_prime = 62523021
#     N = p * q
#     C_prime_calculated = pow(P_prime, e, N)
#     print("C_prime_calculated =", C_prime_calculated)


if __name__ == "__main__":
    # Q2 - 1st
    cal_n_phi_N()

    # Q2 - 2nd
    e = 3
    Φ_n = 68238256
    print('Q2 - 2nd: Find the greatest common divisor (GCD) of e = 3 and Φ(N) = 68 238 256 is', gcd(e, Φ_n))

    # Q2 - 3rd
    print('Q2 - 3rd: The inverse of e mod Φ(N) is', find_inverse(e, Φ_n))

    # Q2 - 4th
    encrypt()

    # Q2 - 5th
    decryption_c()

    # Q2 - 6th
    decryption_c_p()

    # Q2 - 7th
    encript_p_prime()

    # extended_euclidean_algorithm_ver2()
    # Output: Q2 - 3rd: d =  the inverse of e mod Φ(N) = 45492171

    # encrypt_4th()
    # Output: Q2 - 4th: C = 23081176

    #decryption_c_p_6th()

