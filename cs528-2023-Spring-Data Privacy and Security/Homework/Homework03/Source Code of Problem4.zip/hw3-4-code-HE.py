from phe import paillier
# from pypaillier import paillier
import numpy as np

# Generate Paillier keypair
public_key, private_key = paillier.generate_paillier_keypair()

# Alice's vector
Va = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).tolist()

# Bob's vector
Vb = np.array([2, 3 ,4 ,5 ,6 ,7 ,8 ,9 ,10 ,11]).tolist()

# Chris' vector
Vc = np.array([3 ,4 ,5 ,6 ,7 ,8 ,9 ,10 ,11 ,12]).tolist()

# David's vector
Vd = np.array([4 ,5 ,6 ,7 ,8 ,9 ,10 ,11,12,13]).tolist()

# Encrypt vectors using public key
encrypted_Va = [public_key.encrypt(x) for x in Va]
encrypted_Vb = [public_key.encrypt(x) for x in Vb]
encrypted_Vc = [public_key.encrypt(x) for x in Vc]
encrypted_Vd = [public_key.encrypt(x) for x in Vd]

# Sum encrypted vectors element-wise
encrypted_sum = [sum(x) for x in zip(encrypted_Va,
                                      encrypted_Vb,
                                      encrypted_Vc,
                                      encrypted_Vd)]

# Decrypt sum using private key
decrypted_sum = np.array([private_key.decrypt(x) for x in encrypted_sum])

print("Decrypted sum:", decrypted_sum)

max_value = max(decrypted_sum)
print("Max value:", max_value)