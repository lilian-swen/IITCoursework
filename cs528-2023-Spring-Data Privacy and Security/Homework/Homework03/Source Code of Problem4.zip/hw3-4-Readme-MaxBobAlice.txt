Created by: Yuanyuan Sun
Based on: Fairplay readme file

A. Examples for compiling an SFDL program:
------------------------------------------

1. ./run_bob -c progs/MaxAliceBob.txt
2. ./run_alice -c progs/MaxAliceBob.txt

(-c for compile,
 progs/MaxAliceBob.txt - SFDL program to compile)

Both commands produce the same two output files: 
1. progs/MaxAliceBob.txt.Opt.circuit (an SHDL circuit)
2. progs/MaxAliceBob.txt.Opt.fmt



B. Example for running Bob (should be first):
---------------------------------------------
./run_bob -r progs/MaxAliceBob.txt "S&b~n2#m8_Q" 4

(-r for run,
 progs/MaxAliceBob.txt - program to run,
 3rd parameter - crazy string for random seed,
 4th parameter - OT type [1-4], 4 is the best one)



C. Example for running Alice (should be second):
------------------------------------------------

./run_alice -r progs/MaxAliceBob.txt 5miQ^0s1 localhost

(-r for run,
 progs/MaxAliceBob.txt - program to run,
 3rd parameter - crazy string for random seed,
 4th parameter - hostname where Bob is)


D. Some general comments:
-------------------------

1. As with regular programs - first compile, then run.
2. Bob & Alice use fixed port (no. 3496) for TCP/IP communication.
