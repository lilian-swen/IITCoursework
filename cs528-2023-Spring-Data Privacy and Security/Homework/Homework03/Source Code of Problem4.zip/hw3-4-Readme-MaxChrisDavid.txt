Created by: Yuanyuan Sun
Based on: Fairplay readme file

A. Examples for compiling an SFDL program:
------------------------------------------

1. ./run_chris -c progs/MaxChrisDavid.txt
2. ./run_david -c progs/MaxChrisDavid.txt

(-c for compile,
 progs/MaxChrisDavid.txt - SFDL program to compile)

Both commands produce the same two output files: 
1. progs/MaxChrisDavid.txt.Opt.circuit (an SHDL circuit)
2. progs/MaxChrisDavid.txt.Opt.fmt



B. Example for running Bob (should be first):
---------------------------------------------
./run_chris -r progs/MaxChrisDavid.txt "S&b~n2#m8_Q" 4

(-r for run,
 progs/MaxChrisDavid.txt - program to run,
 3rd parameter - crazy string for random seed,
 4th parameter - OT type [1-4], 4 is the best one)



C. Example for running Alice (should be second):
------------------------------------------------

./run_david -r progs/MaxChrisDavid.txt 5miQ^0s1 localhost

(-r for run,
 progs/MaxChrisDavid.txt - program to run,
 3rd parameter - crazy string for random seed,
 4th parameter - hostname where Bob is)


D. Some general comments:
-------------------------

1. As with regular programs - first compile, then run.
2. Bob & Alice use fixed port (no. 3496) for TCP/IP communication.
